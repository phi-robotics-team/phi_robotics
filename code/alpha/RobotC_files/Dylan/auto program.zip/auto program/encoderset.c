//#include "int.h"
void pramaset (int pramavalue,  )
{
    char motorset[10] = encoder;

  if(pramavalue == 2)
  {
   strcpy(E1 , motorset);

  }
  else if(pramavalue == 3)
  {

   strcpy(E2 , motorset);

  }
  else if(pramavalue == 5)
  {

   strcpy(E3 , motorset);

  }
  else if(pramavalue == 6)
  {

   strcpy(E4 , motorset);

  }
  else if(pramavalue == 10)
  {

   strcpy(E5 , motorset);

  }
  else if(pramavalue == 11)
  {

   strcpy(E6 , motorset);

  }
  else if(pramavalue == 17)
  {
   strcpy(E7 , motorset);

  }
  else if(pramavalue == 18)
  {

   strcpy(E8 , motorset);

  }
}
