void mypause ( void )
{
  printf ( "Press enter to exit..." );
  fflush ( stdout );
  getchar();
}
