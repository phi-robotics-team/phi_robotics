char m1[20],m2[20],m3[20],m4[20],m5[20],m6[20],m7[20],m8[20];
char rightmotor[20], leftmotor[20], backright[20], backleft[20];
int motorcount, pramavalue, controler1, port1, controler2, port2, controler3, port3, controler4, port4, pramavalue1, pramavalue2, pramavalue3, pramavalue4, pramavalue9;
char name[20], stop;
