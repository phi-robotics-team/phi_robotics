#include "int.h"
void pramaset (int pramavalue, char motorset[10])
{


  if(pramavalue == 2)
  {
   strcpy(m1 , motorset);

  }
  else if(pramavalue == 3)
  {

   strcpy(m2 , motorset);

  }
  else if(pramavalue == 5)
  {

   strcpy(m3 , motorset);

  }
  else if(pramavalue == 6)
  {

   strcpy(m4 , motorset);

  }
  else if(pramavalue == 10)
  {

   strcpy(m5 , motorset);

  }
  else if(pramavalue == 11)
  {

   strcpy(m6 , motorset);

  }
  else if(pramavalue == 17)
  {
   strcpy(m7 , motorset);

  }
  else if(pramavalue == 18)
  {

   strcpy(m8 , motorset);

  }
}
